# The BayWheels Trip Data
## by Abdullah Aljamhour


## Dataset

> The data is information about a bike renting app, this data provides infomation like the age of the user, duration of the use, gender of the user, and more. 


## Summary of Findings

> I found out that the from the data that most of the users are male, There's more subscribers to the service than non-subscribers. The date of birth of users fall between (1987 - 1997), and non-subscribers users use the service in a longer period than subscribers.


## Key Insights for Presentation

> for the presentation I'll start with showing the univariable and how they are distributed then I'll show the bivariate and plot the variables that I'm interested to study. Then finally I'll use the multivariate plot of the 3 variables that I was studying to show the conclusion.
